package com.studentportal.manager.model;

import com.studentportal.manager.exception.InvalidInputException;

import java.time.LocalDate;

public class FeePayment {
    private final LocalDate date;
    private final double amount;
    private final String description;

    public FeePayment(LocalDate date, double amount, String description) throws InvalidInputException {
        if (date == null) {
            throw new InvalidInputException("Payment date is required.");
        }
        if (amount <= 0) {
            throw new InvalidInputException("Payment amount must be greater than zero.");
        }
        this.date = date;
        this.amount = amount;
        this.description = description == null || description.trim().isEmpty() ? "School fees" : description.trim();
    }

    public LocalDate getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }
}
