package com.studentportal.manager.model;

import com.studentportal.manager.exception.InvalidInputException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Student extends Person {
    private String programme;
    private String classLevel;
    private String guardian;
    private double totalFees;
    private final List<SubjectResult> results = new ArrayList<>();
    private final List<AttendanceRecord> attendance = new ArrayList<>();
    private final List<FeePayment> payments = new ArrayList<>();

    public Student(String id, String name, String phone, String programme, String classLevel, String guardian, double totalFees)
            throws InvalidInputException {
        super(id, name, phone);
        setProgramme(programme);
        setClassLevel(classLevel);
        setGuardian(guardian);
        setTotalFees(totalFees);
    }

    @Override
    public String getCategory() {
        return "Student";
    }

    public String getProgramme() {
        return programme;
    }

    public void setProgramme(String programme) throws InvalidInputException {
        if (programme == null || programme.trim().isEmpty()) {
            throw new InvalidInputException("Programme is required.");
        }
        this.programme = programme.trim();
    }

    public String getClassLevel() {
        return classLevel;
    }

    public void setClassLevel(String classLevel) throws InvalidInputException {
        if (classLevel == null || classLevel.trim().isEmpty()) {
            throw new InvalidInputException("Class level is required.");
        }
        this.classLevel = classLevel.trim();
    }

    public String getGuardian() {
        return guardian;
    }

    public void setGuardian(String guardian) throws InvalidInputException {
        if (guardian == null || guardian.trim().isEmpty()) {
            throw new InvalidInputException("Guardian name is required.");
        }
        this.guardian = guardian.trim();
    }

    public double getTotalFees() {
        return totalFees;
    }

    public void setTotalFees(double totalFees) throws InvalidInputException {
        if (totalFees < 0) {
            throw new InvalidInputException("Total fees cannot be negative.");
        }
        this.totalFees = totalFees;
    }

    public void addResult(SubjectResult result) throws InvalidInputException {
        if (result == null) {
            throw new InvalidInputException("Subject result is required.");
        }
        results.add(result);
    }

    public void addAttendance(AttendanceRecord record) throws InvalidInputException {
        if (record == null) {
            throw new InvalidInputException("Attendance record is required.");
        }
        attendance.add(record);
    }

    public void addPayment(FeePayment payment) throws InvalidInputException {
        if (payment == null) {
            throw new InvalidInputException("Fee payment is required.");
        }
        payments.add(payment);
    }

    public List<SubjectResult> getResults() {
        return Collections.unmodifiableList(results);
    }

    public List<AttendanceRecord> getAttendance() {
        return Collections.unmodifiableList(attendance);
    }

    public List<FeePayment> getPayments() {
        return Collections.unmodifiableList(payments);
    }

    public double averageScore() {
        if (results.isEmpty()) {
            return 0.0;
        }
        int total = 0;
        for (SubjectResult result : results) {
            total += result.getScore();
        }
        return total / (double) results.size();
    }

    public double attendancePercent() {
        if (attendance.isEmpty()) {
            return 0.0;
        }
        int present = 0;
        for (AttendanceRecord record : attendance) {
            if (record.isPresent()) {
                present++;
            }
        }
        return present * 100.0 / attendance.size();
    }

    public double totalPaid() {
        double paid = 0.0;
        for (FeePayment payment : payments) {
            paid += payment.getAmount();
        }
        return paid;
    }

    public double balance() {
        return totalFees - totalPaid();
    }

    @Override
    public String toString() {
        return getId() + " - " + getName();
    }
}
