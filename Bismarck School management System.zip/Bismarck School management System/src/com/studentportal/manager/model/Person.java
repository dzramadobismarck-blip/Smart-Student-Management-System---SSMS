package com.studentportal.manager.model;

import com.studentportal.manager.exception.InvalidInputException;

public abstract class Person {
    private final String id;
    private String name;
    private String phone;

    protected Person(String id, String name, String phone) throws InvalidInputException {
        if (id == null || id.trim().isEmpty()) {
            throw new InvalidInputException("ID is required.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new InvalidInputException("Name is required.");
        }
        this.id = id.trim().toUpperCase();
        this.name = name.trim();
        this.phone = phone == null ? "" : phone.trim();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) throws InvalidInputException {
        if (name == null || name.trim().isEmpty()) {
            throw new InvalidInputException("Name is required.");
        }
        this.name = name.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? "" : phone.trim();
    }

    public abstract String getCategory();
}
