package com.studentportal.manager.model;

import com.studentportal.manager.exception.InvalidInputException;

import java.time.LocalDate;

public class AttendanceRecord {
    private final LocalDate date;
    private final boolean present;
    private final String note;

    public AttendanceRecord(LocalDate date, boolean present, String note) throws InvalidInputException {
        if (date == null) {
            throw new InvalidInputException("Attendance date is required.");
        }
        this.date = date;
        this.present = present;
        this.note = note == null ? "" : note.trim();
    }

    public LocalDate getDate() {
        return date;
    }

    public boolean isPresent() {
        return present;
    }

    public String getNote() {
        return note;
    }
}
