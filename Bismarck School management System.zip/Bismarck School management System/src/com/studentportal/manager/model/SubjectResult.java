package com.studentportal.manager.model;

import com.studentportal.manager.exception.InvalidInputException;

public class SubjectResult {
    private final String subjectCode;
    private final String subjectName;
    private final int score;

    public SubjectResult(String subjectCode, String subjectName, int score) throws InvalidInputException {
        if (subjectCode == null || subjectCode.trim().isEmpty()) {
            throw new InvalidInputException("Subject code is required.");
        }
        if (subjectName == null || subjectName.trim().isEmpty()) {
            throw new InvalidInputException("Subject name is required.");
        }
        if (score < 0 || score > 100) {
            throw new InvalidInputException("Score must be between 0 and 100.");
        }
        this.subjectCode = subjectCode.trim().toUpperCase();
        this.subjectName = subjectName.trim();
        this.score = score;
    }

    public String getSubjectCode() {
        return subjectCode;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public int getScore() {
        return score;
    }

    public String getGrade() {
        if (score >= 80) {
            return "A";
        }
        if (score >= 70) {
            return "B+";
        }
        if (score >= 60) {
            return "B";
        }
        if (score >= 50) {
            return "C";
        }
        if (score >= 40) {
            return "D";
        }
        return "F";
    }
}
