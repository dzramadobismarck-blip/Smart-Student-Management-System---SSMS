package com.studentportal.manager.gui;

import com.studentportal.manager.exception.InvalidInputException;
import com.studentportal.manager.formatter.StudentReportFormatter;
import com.studentportal.manager.model.AttendanceRecord;
import com.studentportal.manager.model.FeePayment;
import com.studentportal.manager.model.Student;
import com.studentportal.manager.model.SubjectResult;
import com.studentportal.manager.service.AuthService;
import com.studentportal.manager.service.SmartStatusService;
import com.studentportal.manager.service.StudentRepository;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.List;

public class MainFrame extends JFrame {
    private static final String LOGIN = "login";
    private static final String HOME = "home";
    private static final String STUDENTS = "students";
    private static final String ATTENDANCE = "attendance";
    private static final String RESULTS = "results";
    private static final String FEES = "fees";
    private static final String REPORTS = "reports";

    private final AuthService authService = new AuthService();
    private final StudentRepository repository = new StudentRepository();
    private final SmartStatusService statusService = new SmartStatusService();
    private final StudentReportFormatter reportFormatter = new StudentReportFormatter();
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cards = new JPanel(cardLayout);

    private final DefaultTableModel studentsModel = new DefaultTableModel(
            new String[]{"ID", "Name", "Programme", "Class", "Average", "Attendance", "Balance", "Status"}, 0);
    private final JTable studentsTable = new JTable(studentsModel);
    private final DefaultTableModel attendanceModel = new DefaultTableModel(new String[]{"Date", "Status", "Note"}, 0);
    private final JTable attendanceTable = new JTable(attendanceModel);
    private final DefaultTableModel resultsModel = new DefaultTableModel(new String[]{"Code", "Subject", "Score", "Grade"}, 0);
    private final JTable resultsTable = new JTable(resultsModel);
    private final DefaultTableModel feesModel = new DefaultTableModel(new String[]{"Date", "Amount", "Description"}, 0);
    private final JTable feesTable = new JTable(feesModel);
    private final JTextArea reportArea = new JTextArea();
    private final JTextArea attendanceSummaryArea = new JTextArea();
    private final JTextArea resultsSummaryArea = new JTextArea();
    private final JTextArea feesSummaryArea = new JTextArea();
    private final JTextField searchField = new JTextField(20);

    private final JTextField idField = new JTextField(12);
    private final JTextField nameField = new JTextField(16);
    private final JTextField phoneField = new JTextField(12);
    private final JTextField programmeField = new JTextField("General Arts", 16);
    private final JComboBox<String> classBox = new JComboBox<>(new String[]{"SHS 1", "SHS 2", "SHS 3"});
    private final JTextField guardianField = new JTextField(16);
    private final JSpinner totalFeesSpinner = new JSpinner(new SpinnerNumberModel(3000.0, 0.0, 100000.0, 50.0));

    private Student selectedStudent;

    public MainFrame() {
        super("Smart Student Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1150, 720));
        setSize(1150, 720);
        setLocationRelativeTo(null);

        cards.add(loginPage(), LOGIN);
        cards.add(homePage(), HOME);
        cards.add(studentsPage(), STUDENTS);
        cards.add(attendancePage(), ATTENDANCE);
        cards.add(resultsPage(), RESULTS);
        cards.add(feesPage(), FEES);
        cards.add(reportsPage(), REPORTS);
        add(cards);
        refreshStudents(repository.all());
        cardLayout.show(cards, LOGIN);
    }

    private JPanel loginPage() {
        JPanel page = page();
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(AppTheme.PANEL);
        form.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(new java.awt.Color(213, 196, 231)),
                javax.swing.BorderFactory.createEmptyBorder(30, 36, 30, 36)));

        JTextField username = new JTextField("admin", 16);
        JTextField pin = new JTextField("2026", 16);
        JButton login = new JButton("Enter System");
        AppTheme.accentButton(login);

        row(form, 0, AppTheme.title("Smart Student Management System"), null);
        row(form, 1, AppTheme.section("Administrator Login"), null);
        row(form, 2, new JLabel("Username"), username);
        row(form, 3, new JLabel("PIN"), pin);
        row(form, 4, new JLabel(""), login);

        login.addActionListener(event -> {
            try {
                authService.login(username.getText(), pin.getText());
                cardLayout.show(cards, HOME);
            } catch (InvalidInputException ex) {
                error(ex.getMessage());
            }
        });
        page.add(form, BorderLayout.CENTER);
        return page;
    }

    private JPanel homePage() {
        JPanel page = page();
        page.add(header("Home", "Choose a page to manage a different part of the student record."), BorderLayout.NORTH);
        JPanel menu = new JPanel(new GridBagLayout());
        menu.setOpaque(false);
        addMenuButton(menu, "Students", 0, STUDENTS);
        addMenuButton(menu, "Attendance", 1, ATTENDANCE);
        addMenuButton(menu, "Results", 2, RESULTS);
        addMenuButton(menu, "Fees", 3, FEES);
        addMenuButton(menu, "Reports", 4, REPORTS);
        page.add(menu, BorderLayout.CENTER);
        return page;
    }

    private JPanel studentsPage() {
        JPanel page = pageWithNav("Students", "Add, update, delete, and search student profiles.");
        JPanel center = new JPanel(new BorderLayout(0, 10));
        center.setOpaque(false);
        center.add(searchPanel(), BorderLayout.NORTH);
        center.add(new JScrollPane(studentsTable), BorderLayout.CENTER);
        AppTheme.pad(center);

        studentsTable.setRowHeight(28);
        studentsTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        studentsTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                loadSelectedStudent();
            }
        });

        page.add(center, BorderLayout.CENTER);
        page.add(studentForm(), BorderLayout.EAST);
        return page;
    }

    private JPanel attendancePage() {
        JPanel page = pageWithNav("Attendance", "Record daily attendance for the selected student.");
        JPanel left = selectedSummaryPanel(attendanceSummaryArea);
        JPanel form = formPanel("New Attendance");
        JComboBox<String> presentBox = new JComboBox<>(new String[]{"Present", "Absent"});
        JTextField note = new JTextField(16);
        JButton add = new JButton("Add Attendance");
        AppTheme.button(add);
        row(form, 1, new JLabel("Status"), presentBox);
        row(form, 2, new JLabel("Note"), note);
        row(form, 3, new JLabel(""), add);
        add.addActionListener(event -> {
            if (!ensureStudent()) {
                return;
            }
            try {
                selectedStudent.addAttendance(new AttendanceRecord(LocalDate.now(),
                        "Present".equals(presentBox.getSelectedItem()), note.getText()));
                note.setText("");
                refreshDetailTables();
                updateSummaryAreas();
                refreshStudents(repository.search(searchField.getText()));
            } catch (InvalidInputException ex) {
                error(ex.getMessage());
            }
        });
        left.add(form, BorderLayout.SOUTH);
        page.add(left, BorderLayout.WEST);
        page.add(new JScrollPane(attendanceTable), BorderLayout.CENTER);
        return page;
    }

    private JPanel resultsPage() {
        JPanel page = pageWithNav("Results", "Add subject scores and grades for the selected student.");
        JPanel left = selectedSummaryPanel(resultsSummaryArea);
        JPanel form = formPanel("New Result");
        JTextField code = new JTextField(10);
        JTextField subject = new JTextField(16);
        JSpinner score = new JSpinner(new SpinnerNumberModel(75, 0, 100, 1));
        JButton add = new JButton("Add Result");
        AppTheme.button(add);
        row(form, 1, new JLabel("Code"), code);
        row(form, 2, new JLabel("Subject"), subject);
        row(form, 3, new JLabel("Score"), score);
        row(form, 4, new JLabel(""), add);
        add.addActionListener(event -> {
            if (!ensureStudent()) {
                return;
            }
            try {
                selectedStudent.addResult(new SubjectResult(code.getText(), subject.getText(), (Integer) score.getValue()));
                code.setText("");
                subject.setText("");
                refreshDetailTables();
                updateSummaryAreas();
                refreshStudents(repository.search(searchField.getText()));
            } catch (InvalidInputException ex) {
                error(ex.getMessage());
            }
        });
        left.add(form, BorderLayout.SOUTH);
        page.add(left, BorderLayout.WEST);
        page.add(new JScrollPane(resultsTable), BorderLayout.CENTER);
        return page;
    }

    private JPanel feesPage() {
        JPanel page = pageWithNav("Fees", "Record school-fee payments for the selected student.");
        JPanel left = selectedSummaryPanel(feesSummaryArea);
        JPanel form = formPanel("New Payment");
        JSpinner amount = new JSpinner(new SpinnerNumberModel(500.0, 1.0, 100000.0, 50.0));
        JTextField description = new JTextField("Part payment", 16);
        JButton add = new JButton("Add Payment");
        AppTheme.button(add);
        row(form, 1, new JLabel("Amount"), amount);
        row(form, 2, new JLabel("Description"), description);
        row(form, 3, new JLabel(""), add);
        add.addActionListener(event -> {
            if (!ensureStudent()) {
                return;
            }
            try {
                selectedStudent.addPayment(new FeePayment(LocalDate.now(),
                        ((Number) amount.getValue()).doubleValue(), description.getText()));
                refreshDetailTables();
                updateSummaryAreas();
                refreshStudents(repository.search(searchField.getText()));
            } catch (InvalidInputException ex) {
                error(ex.getMessage());
            }
        });
        left.add(form, BorderLayout.SOUTH);
        page.add(left, BorderLayout.WEST);
        page.add(new JScrollPane(feesTable), BorderLayout.CENTER);
        return page;
    }

    private JPanel reportsPage() {
        JPanel page = pageWithNav("Reports", "View and export the complete smart student report.");
        reportArea.setFont(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 13));
        reportArea.setEditable(false);
        JButton home = new JButton("Home");
        JButton students = new JButton("Students");
        JButton refresh = new JButton("Refresh Report");
        JButton export = new JButton("Export Report");
        AppTheme.button(home);
        AppTheme.button(students);
        AppTheme.button(refresh);
        AppTheme.accentButton(export);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        actions.add(home);
        actions.add(students);
        actions.add(refresh);
        actions.add(export);
        home.addActionListener(event -> cardLayout.show(cards, HOME));
        students.addActionListener(event -> cardLayout.show(cards, STUDENTS));
        refresh.addActionListener(event -> showReport());
        export.addActionListener(event -> exportReport());
        page.add(actions, BorderLayout.SOUTH);
        page.add(new JScrollPane(reportArea), BorderLayout.CENTER);
        return page;
    }

    private JPanel searchPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setOpaque(false);
        JLabel label = new JLabel("Search");
        label.setFont(AppTheme.BODY.deriveFont(java.awt.Font.BOLD));
        searchField.setFont(AppTheme.BODY);
        panel.add(label);
        panel.add(searchField);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                refreshStudents(repository.search(searchField.getText()));
            }

            public void removeUpdate(DocumentEvent e) {
                refreshStudents(repository.search(searchField.getText()));
            }

            public void changedUpdate(DocumentEvent e) {
                refreshStudents(repository.search(searchField.getText()));
            }
        });
        return panel;
    }

    private JPanel studentForm() {
        JPanel form = formPanel("Student Profile");
        row(form, 1, new JLabel("ID"), idField);
        row(form, 2, new JLabel("Name"), nameField);
        row(form, 3, new JLabel("Phone"), phoneField);
        row(form, 4, new JLabel("Programme"), programmeField);
        row(form, 5, new JLabel("Class"), classBox);
        row(form, 6, new JLabel("Guardian"), guardianField);
        row(form, 7, new JLabel("Total Fees"), totalFeesSpinner);
        JButton add = new JButton("Add");
        JButton update = new JButton("Update");
        JButton delete = new JButton("Delete");
        JButton clear = new JButton("Clear");
        AppTheme.button(add);
        AppTheme.button(update);
        AppTheme.accentButton(delete);
        AppTheme.button(clear);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        actions.add(add);
        actions.add(update);
        actions.add(delete);
        actions.add(clear);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 8;
        c.gridwidth = 2;
        c.fill = GridBagConstraints.HORIZONTAL;
        form.add(actions, c);
        add.addActionListener(event -> addStudent());
        update.addActionListener(event -> updateStudent());
        delete.addActionListener(event -> deleteStudent());
        clear.addActionListener(event -> clearForm());
        return form;
    }

    private JPanel selectedSummaryPanel(JTextArea area) {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setOpaque(false);
        area.setText(selectedStudent == null ? "No student selected.\nGo to Students page and select one." : summaryText());
        area.setEditable(false);
        area.setFont(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 13));
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        panel.setPreferredSize(new Dimension(360, 0));
        AppTheme.pad(panel);
        return panel;
    }

    private void addStudent() {
        try {
            Student student = new Student(idField.getText(), nameField.getText(), phoneField.getText(),
                    programmeField.getText(), String.valueOf(classBox.getSelectedItem()), guardianField.getText(),
                    ((Number) totalFeesSpinner.getValue()).doubleValue());
            repository.add(student);
            selectedStudent = student;
            refreshStudents(repository.search(searchField.getText()));
            refreshDetailTables();
            updateSummaryAreas();
            showReport();
        } catch (InvalidInputException ex) {
            error(ex.getMessage());
        }
    }

    private void updateStudent() {
        if (!ensureStudent()) {
            return;
        }
        try {
            selectedStudent.setName(nameField.getText());
            selectedStudent.setPhone(phoneField.getText());
            selectedStudent.setProgramme(programmeField.getText());
            selectedStudent.setClassLevel(String.valueOf(classBox.getSelectedItem()));
            selectedStudent.setGuardian(guardianField.getText());
            selectedStudent.setTotalFees(((Number) totalFeesSpinner.getValue()).doubleValue());
            refreshStudents(repository.search(searchField.getText()));
            updateSummaryAreas();
            showReport();
        } catch (InvalidInputException ex) {
            error(ex.getMessage());
        }
    }

    private void deleteStudent() {
        if (!ensureStudent()) {
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "Delete selected student?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            repository.delete(selectedStudent.getId());
            selectedStudent = null;
            clearForm();
            refreshStudents(repository.search(searchField.getText()));
            refreshDetailTables();
            updateSummaryAreas();
            reportArea.setText("");
        }
    }

    private void loadSelectedStudent() {
        int row = studentsTable.getSelectedRow();
        if (row < 0) {
            return;
        }
        String id = String.valueOf(studentsModel.getValueAt(row, 0));
        repository.find(id).ifPresent(student -> {
            selectedStudent = student;
            idField.setText(student.getId());
            idField.setEditable(false);
            nameField.setText(student.getName());
            phoneField.setText(student.getPhone());
            programmeField.setText(student.getProgramme());
            classBox.setSelectedItem(student.getClassLevel());
            guardianField.setText(student.getGuardian());
            totalFeesSpinner.setValue(student.getTotalFees());
            refreshDetailTables();
            updateSummaryAreas();
            showReport();
        });
    }

    private void refreshStudents(List<Student> students) {
        studentsModel.setRowCount(0);
        for (Student student : students) {
            studentsModel.addRow(new Object[]{
                    student.getId(),
                    student.getName(),
                    student.getProgramme(),
                    student.getClassLevel(),
                    String.format("%.1f", student.averageScore()),
                    String.format("%.1f%%", student.attendancePercent()),
                    String.format("GHS %.2f", student.balance()),
                    statusService.status(student)
            });
        }
    }

    private void refreshDetailTables() {
        attendanceModel.setRowCount(0);
        resultsModel.setRowCount(0);
        feesModel.setRowCount(0);
        if (selectedStudent == null) {
            return;
        }
        selectedStudent.getAttendance().forEach(record -> attendanceModel.addRow(new Object[]{
                record.getDate(), record.isPresent() ? "Present" : "Absent", record.getNote()
        }));
        selectedStudent.getResults().forEach(result -> resultsModel.addRow(new Object[]{
                result.getSubjectCode(), result.getSubjectName(), result.getScore(), result.getGrade()
        }));
        selectedStudent.getPayments().forEach(payment -> feesModel.addRow(new Object[]{
                payment.getDate(), String.format("GHS %.2f", payment.getAmount()), payment.getDescription()
        }));
    }

    private void showReport() {
        reportArea.setText(reportFormatter.format(selectedStudent));
        reportArea.setCaretPosition(0);
    }

    private void updateSummaryAreas() {
        String text = selectedStudent == null
                ? "No student selected.\nGo to Students page and select one."
                : summaryText();
        attendanceSummaryArea.setText(text);
        resultsSummaryArea.setText(text);
        feesSummaryArea.setText(text);
        attendanceSummaryArea.setCaretPosition(0);
        resultsSummaryArea.setCaretPosition(0);
        feesSummaryArea.setCaretPosition(0);
    }

    private void exportReport() {
        if (!ensureStudent()) {
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File(selectedStudent.getId() + "-smart-report.txt"));
        int option = chooser.showSaveDialog(this);
        if (option == JFileChooser.APPROVE_OPTION) {
            try {
                Files.writeString(chooser.getSelectedFile().toPath(), reportArea.getText());
                JOptionPane.showMessageDialog(this, "Report exported.");
            } catch (IOException ex) {
                error("Could not export report: " + ex.getMessage());
            }
        }
    }

    private String summaryText() {
        return "Selected Student\n\n"
                + selectedStudent.getId() + "\n"
                + selectedStudent.getName() + "\n"
                + selectedStudent.getProgramme() + " - " + selectedStudent.getClassLevel() + "\n"
                + String.format("Average: %.1f%n", selectedStudent.averageScore())
                + String.format("Attendance: %.1f%%%n", selectedStudent.attendancePercent())
                + String.format("Balance: GHS %.2f%n", selectedStudent.balance())
                + "Status: " + statusService.status(selectedStudent) + "\n";
    }

    private void clearForm() {
        idField.setEditable(true);
        idField.setText("");
        nameField.setText("");
        phoneField.setText("");
        programmeField.setText("General Arts");
        classBox.setSelectedIndex(0);
        guardianField.setText("");
        totalFeesSpinner.setValue(3000.0);
        studentsTable.clearSelection();
    }

    private boolean ensureStudent() {
        if (selectedStudent == null) {
            error("Select a student from the Students page first.");
            return false;
        }
        return true;
    }

    private void addMenuButton(JPanel panel, String text, int row, String page) {
        JButton button = new JButton(text);
        AppTheme.button(button);
        button.setPreferredSize(new Dimension(260, 46));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row;
        c.insets = new Insets(8, 8, 8, 8);
        panel.add(button, c);
        button.addActionListener(event -> cardLayout.show(cards, page));
    }

    private JPanel pageWithNav(String title, String subtitle) {
        JPanel page = page();
        page.add(header(title, subtitle), BorderLayout.NORTH);
        JPanel nav = new JPanel(new FlowLayout(FlowLayout.LEFT));
        nav.setOpaque(false);
        JButton home = new JButton("Home");
        JButton students = new JButton("Students");
        JButton reports = new JButton("Reports");
        AppTheme.button(home);
        AppTheme.button(students);
        AppTheme.accentButton(reports);
        nav.add(home);
        nav.add(students);
        nav.add(reports);
        home.addActionListener(event -> cardLayout.show(cards, HOME));
        students.addActionListener(event -> cardLayout.show(cards, STUDENTS));
        reports.addActionListener(event -> {
            showReport();
            cardLayout.show(cards, REPORTS);
        });
        page.add(nav, BorderLayout.SOUTH);
        return page;
    }

    private JPanel header(String title, String subtitle) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(javax.swing.BorderFactory.createEmptyBorder(18, 24, 4, 24));
        panel.add(AppTheme.title(title), BorderLayout.NORTH);
        JLabel sub = new JLabel(subtitle);
        sub.setFont(AppTheme.BODY);
        sub.setForeground(AppTheme.MUTED);
        panel.add(sub, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel formPanel(String title) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(AppTheme.PANEL);
        panel.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createTitledBorder(title),
                javax.swing.BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        AppTheme.pad(panel);
        return panel;
    }

    private JPanel page() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(AppTheme.BACKGROUND);
        return panel;
    }

    private void row(JPanel panel, int row, Component label, Component input) {
        GridBagConstraints labelC = new GridBagConstraints();
        labelC.gridx = 0;
        labelC.gridy = row;
        labelC.anchor = GridBagConstraints.WEST;
        labelC.insets = new Insets(7, 7, 7, 12);
        if (input != null) {
            label.setFont(AppTheme.BODY.deriveFont(java.awt.Font.BOLD));
        }
        if (label instanceof JLabel) {
            ((JLabel) label).setHorizontalAlignment(SwingConstants.LEFT);
        }
        panel.add(label, labelC);
        if (input != null) {
            input.setFont(AppTheme.BODY);
            GridBagConstraints inputC = new GridBagConstraints();
            inputC.gridx = 1;
            inputC.gridy = row;
            inputC.weightx = 1.0;
            inputC.fill = GridBagConstraints.HORIZONTAL;
            inputC.insets = new Insets(7, 7, 7, 7);
            panel.add(input, inputC);
        }
    }

    private void error(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }
}
