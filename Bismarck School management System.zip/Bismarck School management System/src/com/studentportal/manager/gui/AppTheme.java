package com.studentportal.manager.gui;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;

public final class AppTheme {
    public static final Color BACKGROUND = new Color(248, 245, 255);
    public static final Color PANEL = Color.WHITE;
    public static final Color PRIMARY = new Color(88, 28, 135);
    public static final Color ACCENT = new Color(14, 165, 233);
    public static final Color TEXT = new Color(31, 41, 55);
    public static final Color MUTED = new Color(100, 116, 139);

    public static final Font TITLE = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font SECTION = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font BODY = new Font("Segoe UI", Font.PLAIN, 15);
    public static final Font BUTTON = new Font("Segoe UI", Font.BOLD, 15);

    private AppTheme() {
    }

    public static JLabel title(String text) {
        JLabel label = new JLabel(text);
        label.setFont(TITLE);
        label.setForeground(PRIMARY);
        return label;
    }

    public static JLabel section(String text) {
        JLabel label = new JLabel(text);
        label.setFont(SECTION);
        label.setForeground(TEXT);
        return label;
    }

    public static void button(JButton button) {
        button.setFont(BUTTON);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorderPainted(false);
        button.setBackground(PRIMARY);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(9, 16, 9, 16));
    }

    public static void accentButton(JButton button) {
        button(button);
        button.setBackground(ACCENT);
    }

    public static void pad(JComponent component) {
        component.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
    }
}
