package com.studentportal.manager.service;

import com.studentportal.manager.exception.InvalidInputException;

public class AuthService {
    public boolean login(String username, String pin) throws InvalidInputException {
        if (username == null || username.trim().isEmpty()) {
            throw new InvalidInputException("Username is required.");
        }
        if (pin == null || pin.trim().isEmpty()) {
            throw new InvalidInputException("PIN is required.");
        }
        if (!"admin".equalsIgnoreCase(username.trim()) || !"2026".equals(pin.trim())) {
            throw new InvalidInputException("Invalid username or PIN.");
        }
        return true;
    }
}
