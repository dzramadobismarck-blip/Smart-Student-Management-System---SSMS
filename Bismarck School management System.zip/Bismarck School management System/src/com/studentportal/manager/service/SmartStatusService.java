package com.studentportal.manager.service;

import com.studentportal.manager.model.Student;

public class SmartStatusService {
    public String status(Student student) {
        if (student == null) {
            return "No Student";
        }
        double average = student.averageScore();
        double attendance = student.attendancePercent();
        double balance = student.balance();

        if (average >= 75 && attendance >= 85 && balance <= 0) {
            return "Excellent";
        }
        if (average >= 60 && attendance >= 70 && balance <= 500) {
            return "Stable";
        }
        if (average >= 50 || attendance >= 60) {
            return "Needs Attention";
        }
        return "Critical";
    }

    public String advice(Student student) {
        String status = status(student);
        if ("Excellent".equals(status)) {
            return "Maintain performance and consider leadership or scholarship opportunities.";
        }
        if ("Stable".equals(status)) {
            return "Continue normal monitoring and encourage regular revision.";
        }
        if ("Needs Attention".equals(status)) {
            return "Plan teacher follow-up, attendance monitoring, and guardian contact.";
        }
        if ("Critical".equals(status)) {
            return "Arrange urgent intervention meeting with guardian and academic advisor.";
        }
        return "Select a student to view advice.";
    }
}
