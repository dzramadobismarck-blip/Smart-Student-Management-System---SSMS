package com.studentportal.manager.service;

import com.studentportal.manager.exception.InvalidInputException;
import com.studentportal.manager.model.AttendanceRecord;
import com.studentportal.manager.model.FeePayment;
import com.studentportal.manager.model.Student;
import com.studentportal.manager.model.SubjectResult;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StudentRepository {
    private final List<Student> students = new ArrayList<>();

    public StudentRepository() {
        seed();
    }

    public List<Student> all() {
        return Collections.unmodifiableList(students);
    }

    public void add(Student student) throws InvalidInputException {
        if (student == null) {
            throw new InvalidInputException("Student is required.");
        }
        if (find(student.getId()).isPresent()) {
            throw new InvalidInputException("Student ID already exists.");
        }
        students.add(student);
    }

    public boolean delete(String id) {
        return students.removeIf(student -> student.getId().equalsIgnoreCase(id));
    }

    public Optional<Student> find(String id) {
        if (id == null) {
            return Optional.empty();
        }
        return students.stream().filter(student -> student.getId().equalsIgnoreCase(id.trim())).findFirst();
    }

    public List<Student> search(String query) {
        if (query == null || query.trim().isEmpty()) {
            return all();
        }
        String q = query.trim().toLowerCase();
        return students.stream()
                .filter(student -> student.getId().toLowerCase().contains(q)
                        || student.getName().toLowerCase().contains(q)
                        || student.getProgramme().toLowerCase().contains(q)
                        || student.getClassLevel().toLowerCase().contains(q)
                        || student.getGuardian().toLowerCase().contains(q))
                .collect(Collectors.toList());
    }

    private void seed() {
        try {
            Student nana = new Student("MPG001", "Nana Akoto", "0240011001", "General Arts", "SHS 1", "Mrs. Akoto", 2800);
            nana.addResult(new SubjectResult("ENG101", "English Language", 78));
            nana.addResult(new SubjectResult("GOV101", "Government", 81));
            nana.addAttendance(new AttendanceRecord(LocalDate.now().minusDays(2), true, "On time"));
            nana.addAttendance(new AttendanceRecord(LocalDate.now().minusDays(1), true, "Present"));
            nana.addPayment(new FeePayment(LocalDate.now().minusDays(10), 2800, "Full payment"));
            students.add(nana);

            Student selina = new Student("MPG002", "Selina Mensima", "0240022002", "Business", "SHS 2", "Mr. Mensima", 3000);
            selina.addResult(new SubjectResult("ACC201", "Accounting", 58));
            selina.addResult(new SubjectResult("ECO201", "Economics", 63));
            selina.addAttendance(new AttendanceRecord(LocalDate.now().minusDays(2), true, "Present"));
            selina.addAttendance(new AttendanceRecord(LocalDate.now().minusDays(1), false, "Absent"));
            selina.addPayment(new FeePayment(LocalDate.now().minusDays(12), 1600, "Part payment"));
            students.add(selina);

            Student prince = new Student("MPG003", "Prince Asare", "0240033003", "General Science", "SHS 3", "Dr. Asare", 3200);
            prince.addResult(new SubjectResult("BIO301", "Biology", 44));
            prince.addResult(new SubjectResult("CHE301", "Chemistry", 49));
            prince.addAttendance(new AttendanceRecord(LocalDate.now().minusDays(2), false, "Absent"));
            prince.addAttendance(new AttendanceRecord(LocalDate.now().minusDays(1), true, "Present"));
            prince.addPayment(new FeePayment(LocalDate.now().minusDays(20), 900, "Initial payment"));
            students.add(prince);
        } catch (InvalidInputException ex) {
            throw new IllegalStateException("Could not seed students.", ex);
        }
    }
}
