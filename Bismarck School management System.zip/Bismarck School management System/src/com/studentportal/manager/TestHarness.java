package com.studentportal.manager;

import com.studentportal.manager.model.Student;
import com.studentportal.manager.service.SmartStatusService;
import com.studentportal.manager.service.StudentRepository;

public class TestHarness {
    public static void main(String[] args) {
        StudentRepository repository = new StudentRepository();
        SmartStatusService statusService = new SmartStatusService();
        Student student = repository.all().get(1);

        System.out.println("Student: " + student.getName());
        System.out.printf("Average: %.1f%n", student.averageScore());
        System.out.printf("Attendance: %.1f%%%n", student.attendancePercent());
        System.out.printf("Balance: GHS %.2f%n", student.balance());
        System.out.println("Status: " + statusService.status(student));
        System.out.println("Advice: " + statusService.advice(student));
    }
}
