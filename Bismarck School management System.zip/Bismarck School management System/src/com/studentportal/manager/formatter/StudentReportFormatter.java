package com.studentportal.manager.formatter;

import com.studentportal.manager.model.AttendanceRecord;
import com.studentportal.manager.model.FeePayment;
import com.studentportal.manager.model.Student;
import com.studentportal.manager.model.SubjectResult;
import com.studentportal.manager.service.SmartStatusService;

public class StudentReportFormatter {
    private final SmartStatusService statusService = new SmartStatusService();

    public String format(Student student) {
        if (student == null) {
            return "Select a student to view report.";
        }
        StringBuilder builder = new StringBuilder();
        builder.append("SMART STUDENT MANAGEMENT REPORT\n\n");
        builder.append("Student ID : ").append(student.getId()).append("\n");
        builder.append("Name       : ").append(student.getName()).append("\n");
        builder.append("Phone      : ").append(student.getPhone()).append("\n");
        builder.append("Programme  : ").append(student.getProgramme()).append("\n");
        builder.append("Class      : ").append(student.getClassLevel()).append("\n");
        builder.append("Guardian   : ").append(student.getGuardian()).append("\n");
        builder.append(String.format("Average    : %.1f%n", student.averageScore()));
        builder.append(String.format("Attendance : %.1f%%%n", student.attendancePercent()));
        builder.append(String.format("Fees Paid  : GHS %.2f%n", student.totalPaid()));
        builder.append(String.format("Balance    : GHS %.2f%n", student.balance()));
        builder.append("Status     : ").append(statusService.status(student)).append("\n");
        builder.append("Advice     : ").append(statusService.advice(student)).append("\n\n");

        builder.append("RESULTS\n");
        for (SubjectResult result : student.getResults()) {
            builder.append(String.format("%-8s %-22s %3d %s%n",
                    result.getSubjectCode(), shorten(result.getSubjectName(), 22), result.getScore(), result.getGrade()));
        }
        builder.append("\nATTENDANCE\n");
        for (AttendanceRecord record : student.getAttendance()) {
            builder.append(record.getDate()).append(" - ")
                    .append(record.isPresent() ? "Present" : "Absent")
                    .append(" - ").append(record.getNote()).append("\n");
        }
        builder.append("\nPAYMENTS\n");
        for (FeePayment payment : student.getPayments()) {
            builder.append(payment.getDate())
                    .append(String.format(" - GHS %.2f - ", payment.getAmount()))
                    .append(payment.getDescription()).append("\n");
        }
        return builder.toString();
    }

    private String shorten(String text, int limit) {
        if (text.length() <= limit) {
            return text;
        }
        return text.substring(0, limit - 3) + "...";
    }
}
