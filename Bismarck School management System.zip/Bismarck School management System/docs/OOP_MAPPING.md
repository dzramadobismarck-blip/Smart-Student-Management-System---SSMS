# OOP Mapping

| Concept | Implementation |
|---|---|
| Encapsulation | Private fields and public methods in `Person`, `Student`, `SubjectResult`, `AttendanceRecord`, and `FeePayment`. |
| Inheritance | `Student` extends abstract `Person`. |
| Polymorphism | `Student` implements `getCategory()` from `Person`. |
| Abstraction | `Person` is abstract. |
| Exception handling | `InvalidInputException` validates blank fields, scores, fees, and attendance input. |
| Collections | `ArrayList` stores students, results, attendance records, and fee payments. |
| Event handling | Swing listeners drive login, navigation, add, update, delete, export, and record-entry actions. |
| Modularisation | Code is separated into model, service, formatter, exception, and GUI packages. |
