@echo off
setlocal
cd /d "%~dp0"
set "OUT_DIR=%TEMP%\smart-student-multipage-out"
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"
javac -d "%OUT_DIR%" src\com\studentportal\manager\*.java src\com\studentportal\manager\exception\*.java src\com\studentportal\manager\formatter\*.java src\com\studentportal\manager\gui\*.java src\com\studentportal\manager\model\*.java src\com\studentportal\manager\service\*.java
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
java -cp "%OUT_DIR%" com.studentportal.manager.TestHarness
pause
